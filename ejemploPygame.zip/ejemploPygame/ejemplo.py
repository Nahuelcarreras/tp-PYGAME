import pygame   
import time
import random

# Inicialización de Pygame
pygame.init()

# Definir algunas constantes
ANCHO, ALTO = 1200, 600
COLOR_TEXTO = (255, 255, 255)
COLOR_FONDO = (100, 149, 237)  # Azul más oscuro
COLOR_TITULO = (255, 0, 0) 
COLOR_PREGUNTA = (0, 0, 0)
FUENTE_TITULO = pygame.font.SysFont(None, 72)  # Fuente para el título
FUENTE = pygame.font.SysFont(None, 48)
FUENTE_PREGUNTA = pygame.font.SysFont(None, 36)

# Lista de preguntas y respuestas (25 preguntas en total)
preguntas = [
    {"pregunta": "¿Cuál es la capital de Francia?", "respuestas": ["Madrid", "Londres", "París", "Berlín"], "correcta": "París"},
    {"pregunta": "¿Quién pintó la Mona Lisa?", "respuestas": ["Rembrandt", "Van Gogh", "Picasso", "Da Vinci"], "correcta": "Da Vinci"},
    {"pregunta": "¿Cuál es el planeta más grande del sistema solar?", "respuestas": ["Júpiter", "Saturno", "Marte", "Venus"], "correcta": "Júpiter"},
    {"pregunta": "¿Cuántos continentes hay?", "respuestas": ["5", "7", "6", "8"], "correcta": "7"},
    {"pregunta": "¿En qué año comenzó la Segunda Guerra Mundial?", "respuestas": ["1914", "1939", "1941", "1929"], "correcta": "1939"},
    {"pregunta": "¿Qué instrumento musical tiene 88 teclas?", "respuestas": ["Saxo", "Guitarra", "Violín", "Piano"], "correcta": "Piano"},
    {"pregunta": "¿Cuál es el río más largo del mundo?", "respuestas": ["Nilo", "Amazonas", "Yangtsé", "Misisipi"], "correcta": "Amazonas"},
    {"pregunta": "¿Qué planeta es conocido como el 'planeta rojo'?", "respuestas": ["Jupiter", "Venus", "Marte", "Saturno"], "correcta": "Marte"},
    {"pregunta": "¿Qué continente es el más grande en superficie?", "respuestas": ["Asia", "América", "África", "Europa"], "correcta": "Asia"},
    {"pregunta": "¿Qué instrumento musical es de cuerdas y se toca con un arco?", "respuestas": ["Violín", "Piano", "Guitarra", "Flauta"], "correcta": "Violín"},
    {"pregunta": "¿Qué gas es el más abundante en la atmósfera terrestre?", "respuestas": ["Oxigeno", "Nitrogeno", "Dióxido de carbono", "Argón"], "correcta": "Nitrógeno"},
    {"pregunta": "¿Cuál es el órgano más grande del cuerpo humano?", "respuestas": ["Corazon", "Hígado", "Piel", "Pulmón"], "correcta": "Piel"},
    {"pregunta": "¿En qué año llegó el hombre a la Luna por primera vez?", "respuestas": ["1975", "1959", "1969", "1980"], "correcta": "1969"},
    {"pregunta": "¿Qué animal es el mamífero más grande del planeta?", "respuestas": ["Ballena azul", "Elefante", "Jirafa", "Rinoceronte"], "correcta": "Ballena azul"},
    {"pregunta": "¿Cuál es el país con más habitantes del mundo?", "respuestas": ["Rusia", "India", "EE.UU.", "China"], "correcta": "China"},
    {"pregunta": "¿Qué día se celebra la independencia de Estados Unidos?", "respuestas": ["14 de julio", "1 de enero", "4 de julio", "25 de diciembre"], "correcta": "4 de julio"},
    {"pregunta": "¿Quién escribió 'Cien años de soledad'?", "respuestas": ["Mario Vargas Llosa", "Gabriel García Márquez", "Pablo Neruda", "Jorge Luis Borges"], "correcta": "Gabriel García Márquez"},
    {"pregunta": "¿Cuál es el océano más grande?", "respuestas": ["Océano Pacífico", "Océano Atlántico", "Océano Índico", "Océano Ártico"], "correcta": "Océano Pacífico"},
    {"pregunta": "¿Cuál es el símbolo químico del oro?", "respuestas": ["Fe", "Ag", "Au", "Cu"], "correcta": "Au"},
    {"pregunta": "¿En qué continente se encuentra el desierto del Sahara?", "respuestas": ["África", "Asia", "América", "Oceanía"], "correcta": "África"},
    {"pregunta": "¿Qué es la energía solar?", "respuestas": ["Energía obtenida de la biomasa", "Energía obtenida del viento", "Energía obtenida del sol", "Energía obtenida de la tierra"], "correcta": "Energía obtenida del sol"},
    {"pregunta": "¿Cuál es el país más pequeño del mundo?", "respuestas": ["Liechtenstein", "Mónaco", "San Marino", "Vaticano"], "correcta": "Vaticano"},
    {"pregunta": "¿Qué significa la palabra 'Kilig' en filipino?", "respuestas": ["LLuvia intensa", "Felicidad extrema", "Dolor de cabeza", "Mariposa en el estómago"], "correcta": "Mariposa en el estómago"},
    {"pregunta": "¿Qué elemento químico es el más ligero?", "respuestas": ["Helio", "Hidrogeno", "Oxígeno", "Carbono"], "correcta": "Hidrógeno"},
    {"pregunta": "¿Qué país inventó el sushi?", "respuestas": ["Japón", "China", "Corea del Sur", "Tailandia"], "correcta": "Japón"}
]

# Configuración de la pantalla
screen = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Trivia de Preguntas")

# Variables de juego
pregunta_actual = 0
tiempo_limite = 20  # Tiempo en segundos por pregunta
tiempo_restante = tiempo_limite
temporizador_iniciado = False
puntos = 0
retroalimentacion_mostrada = False
tiempo_retroalimentacion = 2  # Tiempo para mostrar la retroalimentación
respuestas_correctas = 0

def dibujar_texto(texto, fuente, superficie, x, y, color=COLOR_TEXTO):
    texto_renderizado = fuente.render(texto, True, color)
    superficie.blit(texto_renderizado, (x, y))

# Función para dibujar un fondo uniforme
def dibujar_fondo_color(surface, color):
    surface.fill(color)

def mostrar_pregunta(pregunta):
    dibujar_fondo_color(screen, COLOR_FONDO)
    
    # Dibujar el título en la parte superior
    dibujar_texto("TriviaPreguntados", FUENTE_TITULO, screen, ANCHO // 2 - 200, 20,  color=COLOR_TITULO)  # Ajusta la posición según sea necesario
    
    dibujar_texto(pregunta['pregunta'], FUENTE_PREGUNTA, screen, 20, 100, color=COLOR_PREGUNTA)
    for i, respuesta in enumerate(pregunta['respuestas']):
        dibujar_texto(f"{i + 1}. {respuesta}", FUENTE, screen, 20, 200 + i * 60)
    dibujar_texto(f"Tiempo restante: {int(tiempo_restante)}", FUENTE, screen, 20, 500)
    dibujar_texto(f"Respuestas correctas: {respuestas_correctas}", FUENTE, screen, ANCHO - 400, 100)  # Cambiado a y=100
    dibujar_texto("Terminar Juego", FUENTE, screen, ANCHO - 300, ALTO - 50, color=(255, 0, 0))  # Botón rojo en esquina

    pygame.display.flip()

def mostrar_resultado(correcto):
    dibujar_fondo_color(screen, COLOR_FONDO)
    mensaje = "¡Respuesta correcta!" if correcto else "Respuesta incorrecta."
    dibujar_texto(mensaje, FUENTE, screen, ANCHO // 4, ALTO // 3)
    pygame.display.flip()

def game_over():
    dibujar_fondo_color(screen, COLOR_FONDO)
    dibujar_texto("¡Juego terminado!", FUENTE, screen, ANCHO // 4, ALTO // 3)
    dibujar_texto(f"Respuestas correctas: {respuestas_correctas}", FUENTE, screen, ANCHO // 4, ALTO // 2)
    pygame.display.flip()
    pygame.time.delay(3000)
    pygame.quit()

def verificar_respuesta(pregunta, respuesta):
    return pregunta['respuestas'][respuesta] == pregunta['correcta']

# Bucle principal del juego
def juego():
    global pregunta_actual, tiempo_restante, temporizador_iniciado, puntos, retroalimentacion_mostrada, respuestas_correctas

    random.shuffle(preguntas)
    correr = True
    while correr:
        if pregunta_actual >= len(preguntas):
            game_over()
            return

        if retroalimentacion_mostrada:
            time.sleep(tiempo_retroalimentacion)
            retroalimentacion_mostrada = False
            continue

        if not temporizador_iniciado:
            tiempo_restante = tiempo_limite
            temporizador_iniciado = True

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                correr = False

            if event.type == pygame.KEYDOWN:
                if event.key in [pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4]:
                    respuesta_seleccionada = event.key - pygame.K_1
                    respuesta_correcta = verificar_respuesta(preguntas[pregunta_actual], respuesta_seleccionada)
                    if respuesta_correcta:
                        puntos += 1
                        respuestas_correctas += 1
                    mostrar_resultado(respuesta_correcta)
                    retroalimentacion_mostrada = True
                    pregunta_actual += 1
                    temporizador_iniciado = False

            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_x, mouse_y = pygame.mouse.get_pos()
                # Verificar si se hace clic en el botón "Terminar Juego"
                if ANCHO - 300 <= mouse_x <= ANCHO - 100 and ALTO - 50 <= mouse_y <= ALTO:
                    game_over()
                    return

        if temporizador_iniciado:
            tiempo_restante -= 1 / 60
            if tiempo_restante <= 0:
                pregunta_actual += 1
                temporizador_iniciado = False

        if not retroalimentacion_mostrada:
            mostrar_pregunta(preguntas[pregunta_actual])

        pygame.time.Clock().tick(60)

    pygame.quit()

if __name__ == "__main__":
    juego()

